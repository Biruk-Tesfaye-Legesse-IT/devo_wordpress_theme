<hr>
<footer class="site-footer">
    <p><?php bloginfo( 'name' ) ?></p>
</footer>
<p>Developed by Devbots &copy;2021</p>
<?php wp_footer() ?>

</body>
</html>